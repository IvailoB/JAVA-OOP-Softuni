package WorkingWithAbstraction.TrafficLights;

public enum Color {
    RED,
    GREEN,
    YELLOW
}
